<template>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1>Directives Exercise</h1>

                <p v-highlight:background.delayed="'green'">Color this</p>

            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1>Filters & Mixins</h1>
                <!-- Exercise 1) -->
                <!-- Build a local Filter which reverses the Text it is applied on -->

                <p>{{ text | reverseString }}</p>

                <!-- Exercise 2 -->
                <!-- Build a global Filter which counts the length of a word and it appends it -->
                <!-- Like this: "Test" => Gets Filtered to => "Test (4)" -->

                <p>{{ text | count }}</p>

                <!-- Exercise 3 -->
                <!-- Do the same as in Exercises 1 & 2, now with Computed Properties -->

                <ex12></ex12>

                <!-- Exercise 4 -->
                <!-- Share the Computed Property rebuilding Exercise 2 via a Mixin -->

                <p>{{ text | count }}</p>



            </div>
        </div>
    </div>
</template>

<script>
    import {ex2} from './ex2.js'
    import reverseCount from './reverseCount.vue'
    export default {
        data (){
            return {
                text: 'Hello World'
            }
        },
        filters: {
            reverseString(value) {
                return value.split('').reverse().join('');
            }
        },
        mixins: [ex2],

        components: {
            ex12: reverseCount
        }
    }
</script>

<style>
</style>
