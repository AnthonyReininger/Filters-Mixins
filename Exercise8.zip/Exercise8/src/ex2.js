export const ex2 = {
    computed: {
        count(value) {
            return value + "(" + value.length + ")";
        }
    }

};