<template>
    <div class="container">
                <p>{{ text | reverseString }}</p>

                <p>{{ text | count }}</p>
    </div>
</template>


<script>
        export default {
            data (){
                return {
                    text: 'Hello World'
                }
            },
            filters: {
                reverseString(value) {
                    return value.split('').reverse().join('');
                },
                count(value) {
                    return value + "(" + value.length + ")";
                }
            }
        }
</script>

<style>

</style>